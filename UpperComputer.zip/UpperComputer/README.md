注意：使用此上位机时，需要实现32的相关配置，其中《stm32配置文件keil》便是，其中包含了一个c和h文件，将这两个文件添加至自己的工程中，然后进行相关的配置，本配置文件需要实现串口的中断的功能，其中串口中断的配置如下：

```c
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
    if(huart->Instance == USART1){
        UartRcinfo.data[UartRcinfo.Length++] = currRx;
        if(UartRcinfo.Length>=65) UartRcinfo.Length = 0;
        if(currRx == '#')packData();
        HAL_UART_Receive_IT(&huart1,&currRx,1);
    }
}
```

记得将此代码块添加进HAL库自带的usart.c中，相关配置可自行思考配置！