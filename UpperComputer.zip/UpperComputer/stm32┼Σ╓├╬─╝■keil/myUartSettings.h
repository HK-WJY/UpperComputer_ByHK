#ifndef __MY_UARTSETTINGS_H__
#define __MY_UARTSETTINGS_H__
#include "main.h"
#include "stdbool.h"

typedef struct{
    uint8_t data[65];
    int Length;
}uart_rcinfo;

extern uart_rcinfo UartRcinfo;
extern uint8_t currRx;
extern uint8_t RxBuff[255];
extern bool isPacked;
extern double PID_SET,P,I,D;

void UARTRCINFO_Init(void);
void packData(void);
void unpackData(void);
#endif
