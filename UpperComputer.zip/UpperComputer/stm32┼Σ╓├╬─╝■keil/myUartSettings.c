#include "myUartSettings.h"
#include "stdio.h"
void UARTRCINFO_Init(void)
{
    UartRcinfo.Length = 0;
    for(int i=0;i<65;i++)UartRcinfo.data[i] = 0;
}

void packData(void)
{
    uint8_t i = 0;
    while(1){
        RxBuff[i] = UartRcinfo.data[i];
        i++;
        if(UartRcinfo.data[i] == '#'){
            break;
        }
    }
    for(i=0;i<65;i++){
        UartRcinfo.data[i] = 0;
    }
    UartRcinfo.Length = 0;
    isPacked = true;
    return;
}

double Ten_Pow(int y){
    uint8_t i=0;
    double target=1.0;
    if(y>0){
        for(i=0;i<y;i++)target *= 10.0;
    }else if(y<0){
        for(i=0;i<-y;i++)target *= 0.1;
    }else{
        return 1.0;
    }
    return target;
    
}

void unpackData(void){
    PID_SET = 0;
    P = 0;
    I = 0;
    D = 0;
    uint8_t set_size = RxBuff[0];/*设定数据长*/
    uint8_t p_size   = RxBuff[1];/*P参数长*/
    uint8_t i_size   = RxBuff[2];/*I参数长*/
    uint8_t d_size   = RxBuff[3];/*D参数长*/
    uint8_t databuff[50]={0};
    uint8_t pbuff[50]={0};
    uint8_t ibuff[50]={0};
    uint8_t dbuff[50]={0};
    
    uint8_t count=0;
    uint8_t i=4;
    uint8_t size1 = 4+set_size;
    uint8_t size2 = 4+set_size+p_size;
    uint8_t size3 = 4+set_size+p_size+i_size;
    uint8_t size4 = 4+set_size+p_size+i_size+d_size;
    for(i=4;i<size1;i++)      databuff[count++] = RxBuff[i];count=0;
    for(i=size1;i<size2;i++)  pbuff[count++] = RxBuff[i];   count=0;
    for(i=size2;i<size3;i++)  ibuff[count++] = RxBuff[i];   count=0;
    for(i=size3;i<size4;i++)  dbuff[count++] = RxBuff[i];   count=0;
    /*字符串化整数*/
    for(i=0;i<set_size;i++)   PID_SET += ((databuff[i]-'0')*Ten_Pow(set_size-1-i));
    /*化小数*/
    bool sign = true;
    int zhengshuwei = 0,xiaoshuwei = -1;
    for(i=0;i<p_size;i++){
        if(pbuff[i] == '.') sign = false;
        if(sign) zhengshuwei++;
        else xiaoshuwei++;
    }i=0;
    for(int j=zhengshuwei-1;j>=-xiaoshuwei;j--,i++){
        if(pbuff[i]=='.')P += ((pbuff[++i] - '0')*Ten_Pow(j));
        else             P += ((pbuff[i] - '0')  *Ten_Pow(j));
    }
    /**/
    zhengshuwei = 0;xiaoshuwei = -1;
    sign = true;
    for(i=0;i<i_size;i++){
        if(ibuff[i] == '.') sign = false;
        if(sign)            zhengshuwei++;
        else                xiaoshuwei++;
    }i=0;
    for(int j=zhengshuwei-1;j>=-xiaoshuwei;j--,i++){
        if(ibuff[i]=='.')I += ((ibuff[++i] - '0')*Ten_Pow(j));
        else             I += ((ibuff[i] - '0')*Ten_Pow(j));
    }
    /**/
    zhengshuwei = 0;xiaoshuwei = -1;
    sign = true;
    for(i=0;i<d_size;i++){  
        if(dbuff[i] == '.') sign = false;
        if(sign)            zhengshuwei++;
        else                xiaoshuwei++;
    }i=0;
    for(int j=zhengshuwei-1;j>=-xiaoshuwei;j--,i++){
        if(dbuff[i]=='.')D += ((dbuff[++i] - '0')*Ten_Pow(j));
        else             D += ((dbuff[i] - '0')*Ten_Pow(j));
    }      
    return;
}
